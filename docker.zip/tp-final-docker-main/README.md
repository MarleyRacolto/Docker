# tp-final-docker

1. Criar index.html e dockerfile 

<img width="572" height="561" alt="1" src="https://github.com/user-attachments/assets/f90baf20-eafd-4089-b8e9-204c6421d2a5" />

2. Buildar imagem customizada 
 
 <img width="570" height="198" alt="2" src="https://github.com/user-attachments/assets/712cc653-8760-4931-9985-d2d933716b6e" />

3. Criar Docker-compose.yml com dois serviços 
 
 
 <img width="567" height="307" alt="3" src="https://github.com/user-attachments/assets/104e9054-0426-4aad-bb03-d68b69608ff5" />

 
4. Subir tudo com Docker-compose up 
 
 <img width="567" height="558" alt="4" src="https://github.com/user-attachments/assets/5f4a3a17-f302-4118-8982-c98008cf517b" />

 
5. Testar nos navegadores localhost (8080, 8081) 
 
 <img width="566" height="199" alt="5" src="https://github.com/user-attachments/assets/29128f43-2f65-46e7-917b-91b2a67c729d" />

 
6. Explorar comandos extras 
 
 <img width="566" height="134" alt="6 1" src="https://github.com/user-attachments/assets/9d2d1c03-227d-48e5-b0f1-b1196790acb1" />

 <img width="563" height="548" alt="6 2" src="https://github.com/user-attachments/assets/4044436c-1934-4d49-9ef7-a3862699cbf0" />

 
 
7. Finalizar com Docker composse down 
<img width="570" height="88" alt="image" src="https://github.com/user-attachments/assets/04855c13-eb16-4629-9617-936d7395bd6f" />
